</div>
<hr>
    <div class="footer">
		<nav align="center">
			<ul class="nav navbar-nav">
				<li><a href="">About</a></li>
				<li><a href="">Developers</a></li>
				<li><a href="">Terms and Conditions</a></li>
			</ul>
		</nav>
	</div>

</body>
</html>