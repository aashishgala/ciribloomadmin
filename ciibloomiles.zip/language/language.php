<?php

$language = array(
    'header' => 'Quizz',
    'site_name' => 'Quizz',
    'site_desc' => 'Quizz description',
    'start_quiz' => 'Start Quizz',
    'quiz_rule' => 'Rules Of Quiz',
    'quiz_exit' => 'Exit Quiz',
    'quiz_continue' => 'Continue',
    'quiz_title' => 'Quizz',
    'quiz_time_left' => 'Time Left',
    'quiz_max_time' => '30',
    'quiz_next' => 'Next',
    'quiz_complete' => 'You\'ve completed the Quiz!',
    'quiz_quit' => 'Quit Quiz',
    'quiz_round1' => 'Quiz Round 1',
    'quiz_round2' => 'Quiz Round 2',
);