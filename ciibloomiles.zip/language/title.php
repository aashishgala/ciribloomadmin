<?php

$lables = array(
    'fn' => 'First Name',
    'ln' => 'Last Name',
    'phone' => 'Mobile Number',
    'pass' => 'Password',
    'email' => 'Email Address',
    'repass' => 'Repeat Password',
    'co_name' => 'Course Name',
    'course' => 'Select Course',
    'module' => 'Module Name',
    'assignment' => 'Assignment Name',
    'sel_module' => 'Select Module',
    '' => '',
    '' => '',
    '' => '',
    '' => '',
);

?>