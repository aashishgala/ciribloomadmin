<?php 

$ArrQuizz['Aesthetic'][] = array(
        'question' => 'Aesthetic\' term was first used in the branch of',
        'question_desc' => 'The first use of the term aesthetics in something like its modern sense is commonly attributed to Alexander Baumgarten in 1735 familiar sense as a distinct branch of philosophy.',
        'choice1' => 'Philosophy',
        'choice2' => 'Science',
        'choice3' => 'Maths',
        'choice4' => 'all of the above',
        'answer' => 'choice4',
);
$ArrQuizz['art'][] = array(
        'question' => 'What is the right solution to create unity',
        'question_desc' => '-', 
        'choice1' => 'Line up photographs and text with the same grid lines.',
        'choice2' => 'Repeat a color, shape, or texture in different areas throughout.', 
        'choice3' => 'Use the same color palette throughout.', 
        'choice4' => 'Any of these', 
        'answer' => 'choice4',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);
$ArrQuizz['art'][] = array(
        'question' => '',
        'question_desc' => '', 
        'choice1' => '',
        'choice2' => '', 
        'choice3' => '', 
        'choice4' => '', 
        'answer' => '',
);

echo "<pre>";
print_r($ArrQuizz);
echo "</pre>";