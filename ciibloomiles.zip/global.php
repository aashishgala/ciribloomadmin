<?php
$ciri_url = 'https://www.ciribloom.co.uk';
?>