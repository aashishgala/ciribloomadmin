<?php
$name='Mangal-Regular';
$type='TTF';
$desc=array (
  'CapHeight' => 1241,
  'XHeight' => 0,
  'FontBBox' => '[-674 -496 1061 1339]',
  'Flags' => 4,
  'Ascent' => 1241,
  'Descent' => -438,
  'Leading' => 0,
  'ItalicAngle' => 0,
  'StemV' => 87,
  'MissingWidth' => 500,
);
$unitsPerEm=2048;
$up=-65;
$ut=59;
$strp=259;
$strs=59;
$ttffile='C:/wamp/www/muhs_edps_dev/MPDF/ttfonts/MANGAL.TTF';
$TTCfontID='0';
$originalsize=143864;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='mangal';
$panose=' 0 0 0 0 4 0 0 0 0 0 0 0';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 1241, -438, 0
// usWinAscent/usWinDescent = 1241, -438
// hhea Ascent/Descent/LineGap = 1241, -438, 0
$useOTL=255;
$rtlPUAstr='';
$GSUBScriptLang=array (
  'deva' => 'DFLT ',
);
$GSUBFeatures=array (
  'deva' => 
  array (
    'DFLT' => 
    array (
      'nukt' => 
      array (
        0 => 0,
      ),
      'akhn' => 
      array (
        0 => 1,
      ),
      'rphf' => 
      array (
        0 => 2,
      ),
      'blwf' => 
      array (
        0 => 3,
      ),
      'half' => 
      array (
        0 => 4,
      ),
      'vatu' => 
      array (
        0 => 6,
        1 => 5,
      ),
      'pres' => 
      array (
        0 => 7,
        1 => 9,
      ),
      'blws' => 
      array (
        0 => 8,
      ),
      'abvs' => 
      array (
        0 => 14,
        1 => 15,
        2 => 16,
        3 => 17,
      ),
      'psts' => 
      array (
        0 => 19,
      ),
      'haln' => 
      array (
        0 => 25,
      ),
    ),
  ),
);
$GSUBLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 129920,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 130532,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 130582,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 130614,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 130646,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 131516,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 132386,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 133256,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 133662,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 5,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 134336,
    ),
    'MarkFilteringSet' => '',
  ),
  10 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135430,
    ),
    'MarkFilteringSet' => '',
  ),
  11 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135446,
    ),
    'MarkFilteringSet' => '',
  ),
  12 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135462,
    ),
    'MarkFilteringSet' => '',
  ),
  13 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135478,
    ),
    'MarkFilteringSet' => '',
  ),
  14 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135500,
    ),
    'MarkFilteringSet' => '',
  ),
  15 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135616,
    ),
    'MarkFilteringSet' => '',
  ),
  16 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135684,
    ),
    'MarkFilteringSet' => '',
  ),
  17 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 135988,
    ),
    'MarkFilteringSet' => '',
  ),
  18 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136110,
    ),
    'MarkFilteringSet' => '',
  ),
  19 => 
  array (
    'Type' => 6,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136132,
    ),
    'MarkFilteringSet' => '',
  ),
  20 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136558,
    ),
    'MarkFilteringSet' => '',
  ),
  21 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136580,
    ),
    'MarkFilteringSet' => '',
  ),
  22 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136602,
    ),
    'MarkFilteringSet' => '',
  ),
  23 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136624,
    ),
    'MarkFilteringSet' => '',
  ),
  24 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136646,
    ),
    'MarkFilteringSet' => '',
  ),
  25 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 136680,
    ),
    'MarkFilteringSet' => '',
  ),
);
$GPOSScriptLang=array (
  'deva' => 'DFLT ',
);
$GPOSFeatures=array (
  'deva' => 
  array (
    'DFLT' => 
    array (
      'abvm' => 
      array (
        0 => 0,
        1 => 1,
        2 => 2,
      ),
      'blwm' => 
      array (
        0 => 6,
        1 => 7,
        2 => 8,
        3 => 9,
      ),
    ),
  ),
);
$GPOSLookups=array (
  0 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 121958,
    ),
    'MarkFilteringSet' => '',
  ),
  1 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 123518,
    ),
    'MarkFilteringSet' => '',
  ),
  2 => 
  array (
    'Type' => 8,
    'Flag' => 256,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 123592,
    ),
    'MarkFilteringSet' => '',
  ),
  3 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 123898,
    ),
    'MarkFilteringSet' => '',
  ),
  4 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 123950,
    ),
    'MarkFilteringSet' => '',
  ),
  5 => 
  array (
    'Type' => 1,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 123926,
    ),
    'MarkFilteringSet' => '',
  ),
  6 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 123972,
    ),
    'MarkFilteringSet' => '',
  ),
  7 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 125412,
    ),
    'MarkFilteringSet' => '',
  ),
  8 => 
  array (
    'Type' => 4,
    'Flag' => 0,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 125504,
    ),
    'MarkFilteringSet' => '',
  ),
  9 => 
  array (
    'Type' => 2,
    'Flag' => 512,
    'SubtableCount' => 1,
    'Subtables' => 
    array (
      0 => 125604,
    ),
    'MarkFilteringSet' => '',
  ),
);
?>