<?php
$name='MonotypeCorsiva';
$type='TTF';
$desc=array (
  'CapHeight' => 637,
  'XHeight' => 433,
  'FontBBox' => '[-240 -307 1159 913]',
  'Flags' => 68,
  'Ascent' => 790,
  'Descent' => -303,
  'Leading' => 0,
  'ItalicAngle' => -14.099990844726562,
  'StemV' => 87,
  'MissingWidth' => 750,
);
$unitsPerEm=2048;
$up=-120;
$ut=50;
$strp=259;
$strs=50;
$ttffile='C:/wamp/www/Dev/EDPS/MPDF/ttfonts/Monotype Corsiva.ttf';
$TTCfontID='0';
$originalsize=157360;
$sip=false;
$smp=false;
$BMPselected=false;
$fontkey='monotype';
$panose=' a 6 3 1 1 1 1 2 1 1 1 1';
$haskerninfo=false;
$haskernGPOS=false;
$hassmallcapsGSUB=false;
$fontmetrics='win';
// TypoAscender/TypoDescender/TypoLineGap = 689, -259, 122
// usWinAscent/usWinDescent = 790, -303
// hhea Ascent/Descent/LineGap = 790, -303, 29
$useOTL=0x0000;
$rtlPUAstr='';
?>