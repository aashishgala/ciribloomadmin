<?php 
$originalsize=106308;
?>