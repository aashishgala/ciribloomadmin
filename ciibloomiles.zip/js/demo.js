let arr_quizz_que = [
    {
        tblAutoId: 1,
        numb: 1,
        question: "Aesthetic' term was first used in the branch of",
        answer: "all of the above",
        explaination: "The first use of the term aesthetics in something like its modern sense is commonly attributed to Alexander Baumgarten in 1735 familiar sense as a distinct branch of philosophy.",
        options: [
            "Philosophy ",
            "Science",
            "Maths",
            "all of the above"
        ]
    },
    {
        tblAutoId: 33,
        numb: 2,
        question: "Non realistic art is known as????..",
        answer: "abstract",
        explaination: "abstract",
        options: [
            "surrealism",
            "abstract",
            "cubism",
            "realism"
        ]
    },
    {
        tblAutoId: 34,
        numb: 3,
        question: "???..style is the artist uses geometric shapes to show what he is trying to paint.",
        answer: "realism",
        explaination: "realism",
        options: [
            "pop art",
            "impressionism",
            "abstract",
            "realism"
        ]
    },
    {
        tblAutoId: 35,
        numb: 4,
        question: "Petroglyphs are ",
        answer: "Images incised in rock",
        explaination: "Images incised in rock",
        options: [
            "Images incised in rock",
            "Paintings on rocks",
            "Blocks",
            "Carvings in Temples"
        ]
    },
    {
        tblAutoId: 36,
        numb: 5,
        question: "The great intellectual movement of Renaissance Italy was ",
        answer: "humanism",
        explaination: "humanism",
        options: [
            "cubism",
            "groupism",
            "fascism",
            "humanism"
        ]
    },
];
